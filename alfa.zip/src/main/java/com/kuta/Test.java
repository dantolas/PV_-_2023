package com.kuta;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.*;

import com.kuta.interfaces.Evaluator;
import com.kuta.objects.Classroom;
import com.kuta.objects.Subject;
import com.kuta.objects.SubjectFromJson;
import com.kuta.objects.Teacher;
import java.util.HashMap;
import java.util.LinkedList;

public class Test {

    
    public static void main(String args[]){
        // long startTime = System.currentTimeMillis();
        // permutation("ABCA");
        // long endTime = System.currentTimeMillis();
        // System.out.println("Run time:"+(double)(endTime-startTime)/1000+"s");

        // try {
        //     System.out.println("Working Directory = " + System.getProperty("user.dir"));
        //     String localDirectory = System.getProperty("user.dir");
        //     String json = SubjectFromJson.readJsonFileToString(localDirectory+"/src/main/resources/schedule.json");
        //     SubjectFromJson[] s = SubjectFromJson.createFromJson(json); 
        //     for (SubjectFromJson subjectFromJson : s) {
        //         System.out.println(subjectFromJson);
        //     }


        // } catch (Exception e) {
        //     e.printStackTrace();
        //     System.out.println(e.getMessage());
        // }

        // ConcurrentLinkedQueue<HashMap<String,ArrayList<Subject>>> queue = new ConcurrentLinkedQueue<>();

        // try {

        //     Lock lock = new ReentrantLock();
        //     AtomicInteger schedulesGenerated = new AtomicInteger(0);


        //     RandomGenerator random = new RandomGenerator(queue,"/src/main/resources/schedule.json",lock,schedulesGenerated);
        //     Watchdog watchdog = new Watchdog(lock, schedulesGenerated);
        //     Pes evaluator = new Pes(queue);

        //     Thread t1 =  new Thread(random);
        //     Thread t2 = new Thread(watchdog);
        //     Thread t3 = new Thread(evaluator);
        //     t2.setPriority(Thread.MAX_PRIORITY);
        //     t3.setPriority(8);

        //     t1.start();
        //     t2.start();
        //     t3.start();

        //     t1.join();
        //     t2.join();
        //     t3.join();

        //     System.out.println("Program finished");
            
            
           
        // } catch (IOException e) {
        //     e.printStackTrace();
        // } catch (InterruptedException e) {
        //     TODO Auto-generated catch block
        //     e.printStackTrace();
        // }

        ReentrantLock lock = new ReentrantLock();
        AtomicInteger schedulesGenerated = new AtomicInteger(0);
        AtomicInteger schedulesRated = new AtomicInteger(0);
        AtomicInteger schedulesBetterThanInitalShared = new AtomicInteger();
        ConcurrentLinkedQueue<byte[][]> generatedSchedules = new ConcurrentLinkedQueue<>();
        AtomicBoolean stopOrder = new AtomicBoolean(false);
        AtomicBoolean keepGenerating = new AtomicBoolean(true);
        byte [][] bestSchedule = Config.INITIAL_SCHEDULE;
        int[] bestScheduleScore = new int[11];


        PermutationGenerator g = new PermutationGenerator(schedulesGenerated, generatedSchedules, stopOrder,keepGenerating);

        Thread[] generatorPool = {
            new Thread(g)
        };

        Pes e1 = new Pes(generatedSchedules,lock,stopOrder,keepGenerating,schedulesBetterThanInitalShared,schedulesRated,bestSchedule,bestScheduleScore) {
            
        };
        Pes e2 = new Pes(generatedSchedules,lock,stopOrder,keepGenerating,schedulesBetterThanInitalShared,schedulesRated,bestSchedule,bestScheduleScore) {
            
        };
        Pes e3 = new Pes(generatedSchedules,lock,stopOrder,keepGenerating,schedulesBetterThanInitalShared,schedulesRated,bestSchedule,bestScheduleScore) {
            
        };
        Thread[] evaluatorPool = {
            new Thread(e3),
            new Thread(e2),
            new Thread(e1)
        };

        Watchdog watchdog = new Watchdog(
            schedulesGenerated, schedulesRated, lock, generatorPool,
            evaluatorPool, bestSchedule,bestScheduleScore,
            stopOrder,schedulesBetterThanInitalShared);

        Thread t = new Thread(watchdog);

        t.start();




                
        
    }


    // private static int getRandomNumber(int range){
    //     return (int)Math.floor(Math.random() * (range));
    // }

    // private static int getRandomNumber(int min,int max){
    //     return (int)Math.floor(Math.random() * (max)+min);
    // }

    // public static void permutation(String s) {
    //     char[] original = s.toCharArray();
    //     char[] clone = new char[s.length()];
    //     boolean[] mark = new boolean[s.length()];
    //     Arrays.fill(mark, false);
    //     List<String> results = new ArrayList<>(); 
    //     permute(original, clone, mark, 0, original.length,results);
    //     for (String string : results) {
    //         System.out.println(string);
    //     }
    // }

    // private static void permute(char[] original, char[] clone, boolean[] mark, int length, int n, List<String> results) {
    //     if (length == n) {
    //         results.add(new String(clone));
    //         return;
    //     }
        
    //     for (int i = 0; i < n; i++) {

    //         if (mark[i]) continue;

    //         if (i > 0 && original[i] == original[i-1] && !mark[i-1]) continue;

    //         mark[i] = true;

    //         clone[length] = original[i];
    //         permute(original, clone, mark, length+1, n,results);

    //         mark[i] = false;
    //     }

    // }

    // private static void permuteNonRecursive(char[] original,char[] clone,boolean[] mark,int position){
    //     for (int i = 0; i < original.length; i++) {
    //         for(int j = 0;  j < original.length; j++){
    //             if(mark[j]){
    //                 continue;
    //             }

    //             if(j > 0 && original[j] == original[j] && !mark[j-1]){
    //                 continue;
    //             }

    //             mark[j] = true;
    //             clone[position] = original[j];

    //         }
    //     }
    // }


}

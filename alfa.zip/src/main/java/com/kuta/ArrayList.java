package com.kuta;

public class ArrayList<T> {

}

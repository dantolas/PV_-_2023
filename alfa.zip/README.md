# Projekt alfa -- Generace Rozvrhu
## Kuta Samuel C4b 

**Toto je program ktery pararelne generuje skolni rozvrhy, hodnoti je a hleda rozvrh s nejlepsim hodnocenim.**

### Potreby pro spusteni
- Nainstalovana **Java** verze *11*+



### Jak program spustit?
Ve slozce **START_HERE** naleznete STARTME.jar java archiv, ktery lze spustit z prikazoveho radku. Navigujte v prikazovem radku do slozky **START_HERE** a pouzijte nasledujici prikaz:
```
java -jar STARTME.jar
```

### Poznamka
Ukol jsem nestihl splnit, zvolil jsem spatnou strukturu programu, bohuzel jsem si toho vsiml az ke konci casove lhuty velice pozde. 

Vim ze bohy za snahu v realnem svete praci neexistuji, ale doufam ze tady mi treba trosicku pomohou.


